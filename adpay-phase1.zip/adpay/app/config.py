import os

from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    "postgresql+asyncpg://adpay:adpay_dev_password@localhost:5432/adpay",
)
REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
