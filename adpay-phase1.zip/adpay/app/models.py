"""
Database schema for the watch-to-earn ad platform.

Money rules:
  * All money is Numeric(14, 4) in KES. Never use float.
  * wallet_ledger is APPEND-ONLY (enforced by a DB trigger in the migration).
    A user's balance is SUM(amount); there is no editable balance column.
  * Campaign budget is deducted atomically in SQL (see README), never read-then-write.
"""
import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Identity,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import ARRAY, INET, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

Money = Numeric(14, 4)


class Base(DeclarativeBase):
    pass


def _uuid_pk() -> Mapped[uuid.UUID]:
    return mapped_column(
        UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()")
    )


def _created_at() -> Mapped[datetime]:
    return mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class User(Base):
    __tablename__ = "users"
    __table_args__ = (
        CheckConstraint("status IN ('active','suspended','banned')", name="ck_users_status"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    phone: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)  # E.164, e.g. +2547...
    country: Mapped[str] = mapped_column(String(2), server_default="KE", nullable=False)
    status: Mapped[str] = mapped_column(String(20), server_default="active", nullable=False)
    phone_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = _created_at()


class Advertiser(Base):
    __tablename__ = "advertisers"

    id: Mapped[uuid.UUID] = _uuid_pk()
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    email: Mapped[str] = mapped_column(String(320), unique=True, nullable=False)
    created_at: Mapped[datetime] = _created_at()


class Campaign(Base):
    __tablename__ = "campaigns"
    __table_args__ = (
        CheckConstraint("cost_per_view > 0", name="ck_campaigns_cpv_positive"),
        CheckConstraint("budget >= 0", name="ck_campaigns_budget_nonneg"),
        CheckConstraint(
            "remaining_budget >= 0 AND remaining_budget <= budget", name="ck_campaigns_remaining_valid"
        ),
        CheckConstraint(
            "status IN ('draft','active','paused','exhausted','ended')", name="ck_campaigns_status"
        ),
        Index("ix_campaigns_status", "status"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    advertiser_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("advertisers.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    cost_per_view: Mapped[Decimal] = mapped_column(Money, nullable=False)  # what the advertiser pays
    budget: Mapped[Decimal] = mapped_column(Money, nullable=False)
    remaining_budget: Mapped[Decimal] = mapped_column(Money, nullable=False)
    status: Mapped[str] = mapped_column(String(20), server_default="draft", nullable=False)
    target_countries: Mapped[list[str]] = mapped_column(
        ARRAY(String(2)), server_default=text("'{KE}'"), nullable=False
    )
    starts_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ends_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = _created_at()


class Ad(Base):
    __tablename__ = "ads"
    __table_args__ = (
        CheckConstraint("duration_seconds > 0", name="ck_ads_duration_positive"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    campaign_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("campaigns.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    video_url: Mapped[str] = mapped_column(Text, nullable=False)
    duration_seconds: Mapped[int] = mapped_column(Integer, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, server_default=text("true"), nullable=False)
    created_at: Mapped[datetime] = _created_at()

    campaign: Mapped["Campaign"] = relationship(lazy="joined")


class ViewSession(Base):
    """One row per ad shown to a user. Rewards are only paid when status moves started -> completed."""

    __tablename__ = "view_sessions"
    __table_args__ = (
        CheckConstraint(
            "status IN ('started','completed','expired','rejected')", name="ck_view_sessions_status"
        ),
        Index("ix_view_sessions_user_started", "user_id", "started_at"),
        Index("ix_view_sessions_device", "device_id"),
        Index("ix_view_sessions_status", "status"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    ad_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("ads.id", ondelete="RESTRICT"), nullable=False)
    campaign_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("campaigns.id", ondelete="RESTRICT"), nullable=False
    )
    status: Mapped[str] = mapped_column(String(20), server_default="started", nullable=False)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reward_amount: Mapped[Decimal | None] = mapped_column(Money)
    ip_address: Mapped[str | None] = mapped_column(INET)
    device_id: Mapped[str | None] = mapped_column(String(128))
    user_agent: Mapped[str | None] = mapped_column(Text)

    ad: Mapped["Ad"] = relationship(lazy="joined")
    campaign: Mapped["Campaign"] = relationship(lazy="joined")


class WalletLedger(Base):
    """Append-only money log. Positive = credit to user, negative = debit. Balance = SUM(amount)."""

    __tablename__ = "wallet_ledger"
    __table_args__ = (
        CheckConstraint("amount <> 0", name="ck_wallet_ledger_amount_nonzero"),
        CheckConstraint(
            "entry_type IN ('view_reward','withdrawal','withdrawal_reversal','adjustment')",
            name="ck_wallet_ledger_entry_type",
        ),
        # Idempotency: the same view session / withdrawal can only create one entry of a given type.
        UniqueConstraint("entry_type", "ref_id", name="uq_wallet_ledger_type_ref"),
        Index("ix_wallet_ledger_user_created", "user_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, Identity(always=True), primary_key=True)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    entry_type: Mapped[str] = mapped_column(String(30), nullable=False)
    ref_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)  # view_session.id or withdrawal.id
    note: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = _created_at()


class Withdrawal(Base):
    __tablename__ = "withdrawals"
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_withdrawals_amount_positive"),
        CheckConstraint(
            "status IN ('pending','processing','completed','failed')", name="ck_withdrawals_status"
        ),
        Index("ix_withdrawals_user_status", "user_id", "status"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    phone: Mapped[str] = mapped_column(String(20), nullable=False)  # M-Pesa number paid out to
    status: Mapped[str] = mapped_column(String(20), server_default="pending", nullable=False)
    provider_ref: Mapped[str | None] = mapped_column(String(64))  # Daraja ConversationID
    mpesa_receipt: Mapped[str | None] = mapped_column(String(32))
    failure_reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = _created_at()
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )


class AdvertiserDeposit(Base):
    """Money coming IN from advertisers (M-Pesa STK Push). Campaign budget is funded from these."""

    __tablename__ = "advertiser_deposits"
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_advertiser_deposits_amount_positive"),
        CheckConstraint(
            "status IN ('pending','confirmed','failed')", name="ck_advertiser_deposits_status"
        ),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    advertiser_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("advertisers.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    campaign_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("campaigns.id", ondelete="SET NULL"))
    amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    mpesa_receipt: Mapped[str | None] = mapped_column(String(32), unique=True)
    status: Mapped[str] = mapped_column(String(20), server_default="pending", nullable=False)
    created_at: Mapped[datetime] = _created_at()
