"""Insert one demo advertiser, campaign, ad and user. Safe to run twice.

Run from the project root:  python -m scripts.seed
"""
import asyncio
from decimal import Decimal

from sqlalchemy import select

from app.db import SessionLocal, engine
from app.models import Ad, Advertiser, Campaign, User


async def main() -> None:
    async with SessionLocal() as db, db.begin():
        exists = await db.scalar(select(Advertiser).where(Advertiser.email == "demo@example.com"))
        if exists:
            print("Already seeded.")
            return

        adv = Advertiser(name="Demo Advertiser", email="demo@example.com")
        db.add(adv)
        await db.flush()

        camp = Campaign(
            advertiser_id=adv.id,
            name="Demo Campaign",
            cost_per_view=Decimal("1.00"),     # advertiser pays KES 1.00 per verified view
            budget=Decimal("500.00"),
            remaining_budget=Decimal("500.00"),
            status="active",
            target_countries=["KE"],
        )
        db.add(camp)
        await db.flush()

        db.add(Ad(campaign_id=camp.id, title="Demo 15s ad",
                  video_url="https://example.com/ad.mp4", duration_seconds=15))
        db.add(User(phone="+254700000000"))
    print("Seeded: 1 advertiser, 1 campaign (KES 500 budget), 1 ad, 1 user.")


if __name__ == "__main__":
    asyncio.run(main())
    asyncio.run(engine.dispose())
