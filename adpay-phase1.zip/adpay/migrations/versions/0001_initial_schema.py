"""initial schema: users, advertisers, campaigns, ads, view_sessions, wallet_ledger, withdrawals, deposits

Revision ID: 0001
Revises:
Create Date: 2026-11-13
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

UUID = postgresql.UUID(as_uuid=True)
MONEY = sa.Numeric(14, 4)
GEN_UUID = sa.text("gen_random_uuid()")
NOW = sa.text("now()")


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", UUID, server_default=GEN_UUID, primary_key=True),
        sa.Column("phone", sa.String(20), nullable=False),
        sa.Column("country", sa.String(2), server_default="KE", nullable=False),
        sa.Column("status", sa.String(20), server_default="active", nullable=False),
        sa.Column("phone_verified_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.UniqueConstraint("phone"),
        sa.CheckConstraint("status IN ('active','suspended','banned')", name="ck_users_status"),
    )

    op.create_table(
        "advertisers",
        sa.Column("id", UUID, server_default=GEN_UUID, primary_key=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("email", sa.String(320), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.UniqueConstraint("email"),
    )

    op.create_table(
        "campaigns",
        sa.Column("id", UUID, server_default=GEN_UUID, primary_key=True),
        sa.Column("advertiser_id", UUID, sa.ForeignKey("advertisers.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("cost_per_view", MONEY, nullable=False),
        sa.Column("budget", MONEY, nullable=False),
        sa.Column("remaining_budget", MONEY, nullable=False),
        sa.Column("status", sa.String(20), server_default="draft", nullable=False),
        sa.Column("target_countries", postgresql.ARRAY(sa.String(2)), server_default=sa.text("'{KE}'"), nullable=False),
        sa.Column("starts_at", sa.DateTime(timezone=True)),
        sa.Column("ends_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.CheckConstraint("cost_per_view > 0", name="ck_campaigns_cpv_positive"),
        sa.CheckConstraint("budget >= 0", name="ck_campaigns_budget_nonneg"),
        sa.CheckConstraint("remaining_budget >= 0 AND remaining_budget <= budget", name="ck_campaigns_remaining_valid"),
        sa.CheckConstraint("status IN ('draft','active','paused','exhausted','ended')", name="ck_campaigns_status"),
    )
    op.create_index("ix_campaigns_advertiser_id", "campaigns", ["advertiser_id"])
    op.create_index("ix_campaigns_status", "campaigns", ["status"])

    op.create_table(
        "ads",
        sa.Column("id", UUID, server_default=GEN_UUID, primary_key=True),
        sa.Column("campaign_id", UUID, sa.ForeignKey("campaigns.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("video_url", sa.Text, nullable=False),
        sa.Column("duration_seconds", sa.Integer, nullable=False),
        sa.Column("is_active", sa.Boolean, server_default=sa.text("true"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.CheckConstraint("duration_seconds > 0", name="ck_ads_duration_positive"),
    )
    op.create_index("ix_ads_campaign_id", "ads", ["campaign_id"])

    op.create_table(
        "view_sessions",
        sa.Column("id", UUID, server_default=GEN_UUID, primary_key=True),
        sa.Column("user_id", UUID, sa.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("ad_id", UUID, sa.ForeignKey("ads.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("campaign_id", UUID, sa.ForeignKey("campaigns.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("status", sa.String(20), server_default="started", nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        sa.Column("reward_amount", MONEY),
        sa.Column("ip_address", postgresql.INET),
        sa.Column("device_id", sa.String(128)),
        sa.Column("user_agent", sa.Text),
        sa.CheckConstraint("status IN ('started','completed','expired','rejected')", name="ck_view_sessions_status"),
    )
    op.create_index("ix_view_sessions_user_started", "view_sessions", ["user_id", "started_at"])
    op.create_index("ix_view_sessions_device", "view_sessions", ["device_id"])
    op.create_index("ix_view_sessions_status", "view_sessions", ["status"])

    op.create_table(
        "wallet_ledger",
        sa.Column("id", sa.BigInteger, sa.Identity(always=True), primary_key=True),
        sa.Column("user_id", UUID, sa.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("amount", MONEY, nullable=False),
        sa.Column("entry_type", sa.String(30), nullable=False),
        sa.Column("ref_id", UUID, nullable=False),
        sa.Column("note", sa.Text),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.CheckConstraint("amount <> 0", name="ck_wallet_ledger_amount_nonzero"),
        sa.CheckConstraint(
            "entry_type IN ('view_reward','withdrawal','withdrawal_reversal','adjustment')",
            name="ck_wallet_ledger_entry_type",
        ),
        sa.UniqueConstraint("entry_type", "ref_id", name="uq_wallet_ledger_type_ref"),
    )
    op.create_index("ix_wallet_ledger_user_created", "wallet_ledger", ["user_id", "created_at"])

    op.create_table(
        "withdrawals",
        sa.Column("id", UUID, server_default=GEN_UUID, primary_key=True),
        sa.Column("user_id", UUID, sa.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("amount", MONEY, nullable=False),
        sa.Column("phone", sa.String(20), nullable=False),
        sa.Column("status", sa.String(20), server_default="pending", nullable=False),
        sa.Column("provider_ref", sa.String(64)),
        sa.Column("mpesa_receipt", sa.String(32)),
        sa.Column("failure_reason", sa.Text),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.CheckConstraint("amount > 0", name="ck_withdrawals_amount_positive"),
        sa.CheckConstraint("status IN ('pending','processing','completed','failed')", name="ck_withdrawals_status"),
    )
    op.create_index("ix_withdrawals_user_status", "withdrawals", ["user_id", "status"])

    op.create_table(
        "advertiser_deposits",
        sa.Column("id", UUID, server_default=GEN_UUID, primary_key=True),
        sa.Column("advertiser_id", UUID, sa.ForeignKey("advertisers.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("campaign_id", UUID, sa.ForeignKey("campaigns.id", ondelete="SET NULL")),
        sa.Column("amount", MONEY, nullable=False),
        sa.Column("mpesa_receipt", sa.String(32)),
        sa.Column("status", sa.String(20), server_default="pending", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=NOW, nullable=False),
        sa.UniqueConstraint("mpesa_receipt"),
        sa.CheckConstraint("amount > 0", name="ck_advertiser_deposits_amount_positive"),
        sa.CheckConstraint("status IN ('pending','confirmed','failed')", name="ck_advertiser_deposits_status"),
    )
    op.create_index("ix_advertiser_deposits_advertiser_id", "advertiser_deposits", ["advertiser_id"])

    # --- Make wallet_ledger truly append-only: block UPDATE and DELETE at the database level ---
    op.execute(
        """
        CREATE FUNCTION wallet_ledger_immutable() RETURNS trigger AS $$
        BEGIN
            RAISE EXCEPTION 'wallet_ledger is append-only: % not allowed', TG_OP;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        """
        CREATE TRIGGER wallet_ledger_no_update_delete
        BEFORE UPDATE OR DELETE ON wallet_ledger
        FOR EACH ROW EXECUTE FUNCTION wallet_ledger_immutable();
        """
    )

    # --- Convenience view: a user's balance is always derived from the ledger ---
    op.execute(
        """
        CREATE VIEW wallet_balances AS
        SELECT user_id, SUM(amount) AS balance
        FROM wallet_ledger
        GROUP BY user_id;
        """
    )


def downgrade() -> None:
    op.execute("DROP VIEW IF EXISTS wallet_balances")
    op.execute("DROP TRIGGER IF EXISTS wallet_ledger_no_update_delete ON wallet_ledger")
    op.execute("DROP FUNCTION IF EXISTS wallet_ledger_immutable()")
    op.drop_table("advertiser_deposits")
    op.drop_table("withdrawals")
    op.drop_table("wallet_ledger")
    op.drop_table("view_sessions")
    op.drop_table("ads")
    op.drop_table("campaigns")
    op.drop_table("advertisers")
    op.drop_table("users")
